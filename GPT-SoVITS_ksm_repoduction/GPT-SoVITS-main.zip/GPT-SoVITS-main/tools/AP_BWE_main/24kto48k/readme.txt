For the inference of the v3 model, if you find that the generated audio sounds somewhat muffled, you can try using this audio super-resolution model.
对于v3模型的推理，如果你发现生成的音频比较闷，可以尝试这个音频超分模型。

put g_24kto48k.zip and config.json in this folder
把g_24kto48k.zip and config.json下到这个文件夹

download link 下载链接:
https://drive.google.com/drive/folders/1IIYTf2zbJWzelu4IftKD6ooHloJ8mnZF?usp=share_link

audio sr project page 音频超分项目主页:
https://github.com/yxlu-0102/AP-BWE
