| Field                                                                                                      | Response                                             |
| :--------------------------------------------------------------------------------------------------------- | :--------------------------------------------------- |
| Participation considerations from adversely impacted groups protected classes in model design and testing: | None                                                 |
| Measures taken to mitigate against unwanted bias:                                                          | No measures taken to mitigate against unwanted bias. |
