<div align="center">


<h1>KiraKsm</h1>

从bestdori爬取邦邦角色纯净语音的简单脚本<br>

</div>

---

## 功能

1. 按角色获取纯人声语音。
2. 可导出适配GPT-SoVITS的索引文件。

## 运行

```bash
pip install -r requirements.txt

python main_ui.py
```

